<template>
	<div class="app-wrapper" :class="{hideSidebar:!sidebar.opened}">
		<sidebar class="sidebar-container"></sidebar>
		<div class="main-container">
			<div class="top_layout_fixed">
				<navbar></navbar>
				<tags-view></tags-view>
			</div>
			
			<app-main></app-main>
		</div>
	</div>
</template>

<script>
import { Navbar, Sidebar, AppMain, TagsView } from './components'

export default {
  name: 'layout',
  components: {
    Navbar,
    Sidebar,
    AppMain,
    TagsView
  },
  computed: {
    sidebar() {
      return this.$store.state.app.sidebar
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
	@import "src/styles/mixin.scss";
	.app-wrapper {
	  @include clearfix;
	  position: relative;
	  height: 100%;
	  width: 100%;
	}
	.top_layout_fixed {
		position: fixed;
		top: 0;
		left: 180px;
		right: 0;
		z-index: 4;
		transition: left .28s;
	}
	#app .hideSidebar .top_layout_fixed {
		left: 36px;
	}
</style>
