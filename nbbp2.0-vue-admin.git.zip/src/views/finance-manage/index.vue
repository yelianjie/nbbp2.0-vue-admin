<template>
 <div>123</div> 
</template>

<script>
export default {
  name: 'finance-Manage'
}
</script>
